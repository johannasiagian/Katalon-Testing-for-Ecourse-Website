<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Weekly outlineGeneralAnnouncements Foru_527bdd</name>
   <tag></tag>
   <elementGuidId>9a16eb9b-322c-48c4-963f-e538fa1c86d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='region-main']/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#region-main > div.card > div.card-body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#region-main div >> internal:has-text=&quot;Weekly outlineGeneralAnnouncements Forum22 January - 28 January29 January - 4 Fe&quot;i >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>55f61616-e1a0-4d4f-9d0d-89e849f6ab32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-body</value>
      <webElementGuid>d34719d9-9e0d-4b49-a60d-789c9c61f5fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                            Weekly outlineGeneralAnnouncements Forum22 January - 28 January29 January - 4 February5 February - 11 FebruaryTugas Random Testing Assignment12 February - 18 FebruaryWeek 4 ART and Functional Testing Assignment19 February - 25 FebruaryW05S02-Whitebox Testing: Control Flow Coverage Assignment26 February - 3 MarchW06S03 : Data Flow Coverage (Data Usage) Assignment4 March - 10 MarchKUIS 1 QuizW07S02_Fault Based Testing Assignment11 March - 17 March18 March - 24 MarchWeek 9 - Regression Testing - Test Suite Reduction Assignment25 March - 31 MarchWeek 10 Regression Testing with Selenium Assignment1 April - 7 AprilWeek 11 - JUnit Assignment8 April - 14 AprilWeek 12 - BDD  AssignmentWeek 12 - ATTD Assignment15 April - 21 April22 April - 28 AprilW13S02-Test Rail [Progress ] AssignmentW13S02_Final Tugas Test Rail AssignmentW13S03_Katalon Studio AssignmentThis week29 April - 5 May6 May - 12 May
                            
                        </value>
      <webElementGuid>2c43d429-4c6b-4fb3-9097-906bd67a8c11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;region-main&quot;)/div[@class=&quot;card&quot;]/div[@class=&quot;card-body&quot;]</value>
      <webElementGuid>2f4d8288-3ebc-4af4-a6e5-a8ed1651db55</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='region-main']/div/div</value>
      <webElementGuid>8628cb88-8513-4ed0-8e74-e3bbb81770d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PKPL TI 2324'])[1]/following::div[6]</value>
      <webElementGuid>d53f2d8a-a4c7-4060-bace-89bcb7ca1663</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My courses'])[1]/following::div[6]</value>
      <webElementGuid>e3388d71-1135-421c-a8bb-c90775131127</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div/div</value>
      <webElementGuid>ff0fef56-7cab-4ad5-95d1-d63d94ea5782</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            
                            Weekly outlineGeneralAnnouncements Forum22 January - 28 January29 January - 4 February5 February - 11 FebruaryTugas Random Testing Assignment12 February - 18 FebruaryWeek 4 ART and Functional Testing Assignment19 February - 25 FebruaryW05S02-Whitebox Testing: Control Flow Coverage Assignment26 February - 3 MarchW06S03 : Data Flow Coverage (Data Usage) Assignment4 March - 10 MarchKUIS 1 QuizW07S02_Fault Based Testing Assignment11 March - 17 March18 March - 24 MarchWeek 9 - Regression Testing - Test Suite Reduction Assignment25 March - 31 MarchWeek 10 Regression Testing with Selenium Assignment1 April - 7 AprilWeek 11 - JUnit Assignment8 April - 14 AprilWeek 12 - BDD  AssignmentWeek 12 - ATTD Assignment15 April - 21 April22 April - 28 AprilW13S02-Test Rail [Progress ] AssignmentW13S02_Final Tugas Test Rail AssignmentW13S03_Katalon Studio AssignmentThis week29 April - 5 May6 May - 12 May
                            
                        ' or . = '
                            
                            Weekly outlineGeneralAnnouncements Forum22 January - 28 January29 January - 4 February5 February - 11 FebruaryTugas Random Testing Assignment12 February - 18 FebruaryWeek 4 ART and Functional Testing Assignment19 February - 25 FebruaryW05S02-Whitebox Testing: Control Flow Coverage Assignment26 February - 3 MarchW06S03 : Data Flow Coverage (Data Usage) Assignment4 March - 10 MarchKUIS 1 QuizW07S02_Fault Based Testing Assignment11 March - 17 March18 March - 24 MarchWeek 9 - Regression Testing - Test Suite Reduction Assignment25 March - 31 MarchWeek 10 Regression Testing with Selenium Assignment1 April - 7 AprilWeek 11 - JUnit Assignment8 April - 14 AprilWeek 12 - BDD  AssignmentWeek 12 - ATTD Assignment15 April - 21 April22 April - 28 AprilW13S02-Test Rail [Progress ] AssignmentW13S02_Final Tugas Test Rail AssignmentW13S03_Katalon Studio AssignmentThis week29 April - 5 May6 May - 12 May
                            
                        ')]</value>
      <webElementGuid>c91eb9e4-bce1-4c61-8219-2d7af02c7eee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
