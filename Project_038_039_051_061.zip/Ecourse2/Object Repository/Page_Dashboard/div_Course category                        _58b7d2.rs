<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Course category                        _58b7d2</name>
   <tag></tag>
   <elementGuidId>4e455071-df07-437f-bf1a-4b987f2d097f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='course-info-container-2564-18']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#course-info-container-2564-18</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#course-info-container-2564-18</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>07e3a08a-bf9e-44c7-a30d-806cfc61c025</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-body pr-1 course-info-container</value>
      <webElementGuid>b9d4066d-a249-49c8-8eb8-d9fb9fe9048b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>course-info-container-2564-18</value>
      <webElementGuid>bbe4adaa-897a-41dc-86a2-3aa7a8da5e2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        </value>
      <webElementGuid>904c18f1-4bb1-4ecb-83df-44b88c1ad44d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;course-info-container-2564-18&quot;)</value>
      <webElementGuid>658f902a-a36f-4940-b987-02c46c8b526d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='course-info-container-2564-18']</value>
      <webElementGuid>0a254895-de66-4951-b8a6-4d119c83f99e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1714398943862_181']/div</value>
      <webElementGuid>e5a37350-01a5-4b0a-a2fe-b14625f25930</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Course image'])[1]/following::div[1]</value>
      <webElementGuid>77295515-ae85-4eed-b046-93b29c63d593</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Card'])[1]/following::div[9]</value>
      <webElementGuid>df248705-e73b-4080-9a22-4ac58a5fbb8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div/div</value>
      <webElementGuid>ed46179b-57de-4037-a2ac-fa097d34bcc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'course-info-container-2564-18' and (text() = '
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        ' or . = '
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        ')]</value>
      <webElementGuid>342c7b67-2eca-488d-9243-197b75dca01d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
