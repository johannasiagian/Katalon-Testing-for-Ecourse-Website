<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Course image                           _7a05a5</name>
   <tag></tag>
   <elementGuidId>dfac1c7d-f4af-4b47-82e5-7a197e3fb669</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='yui_3_17_2_1_1714398943862_181']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#yui_3_17_2_1_1714398943862_181</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#yui_3_17_2_1_1714398943862_181</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5ffbfec3-564b-4f65-a5f7-dc50e3083178</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card dashboard-card</value>
      <webElementGuid>e3d9d002-aeba-481a-9581-e3358c242d8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>listitem</value>
      <webElementGuid>15f37150-827e-4f9b-be6b-6e4629ff8899</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-region</name>
      <type>Main</type>
      <value>course-content</value>
      <webElementGuid>2d4e655b-0585-4d50-b854-0b377856ee2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-course-id</name>
      <type>Main</type>
      <value>2564</value>
      <webElementGuid>82d06ed4-b4af-4639-9fbf-c1939562d329</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>yui_3_17_2_1_1714398943862_181</value>
      <webElementGuid>6a416017-0522-48e1-9f11-e83a280aa656</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                Course image
            
        
        
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        

        </value>
      <webElementGuid>6b2d0399-3338-4f6c-be3a-436830cbbf8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;yui_3_17_2_1_1714398943862_181&quot;)</value>
      <webElementGuid>0fcb2991-1fb0-40ed-bd05-cd3f9289077f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1714398943862_181']</value>
      <webElementGuid>41b1c66b-7fa1-45bd-8c9a-6d2a04502efa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='yui_3_17_2_1_1714398943862_182']/div</value>
      <webElementGuid>cf2dc86d-d832-4b0e-8bfd-106658ef37b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Card'])[1]/following::div[7]</value>
      <webElementGuid>6da284e0-63ed-408c-a283-3a0a161c4099</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last accessed'])[1]/following::div[8]</value>
      <webElementGuid>03b6db85-6ce4-408c-82d2-e00fc143d32d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/div</value>
      <webElementGuid>e4057cac-ab10-4d2b-bbd3-acb20941af07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'yui_3_17_2_1_1714398943862_181' and (text() = '
        
            
                Course image
            
        
        
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        

        ' or . = '
        
            
                Course image
            
        
        
            
                
                    

            
                Course category
            
            
                D3 Teknologi Informasi
            
                        
                    


                        
                            
                                
                                Course is starred
                            
                        
                        
                                Course name
                            

        
            1132204 - Pengujian dan Kualitas Perangkat ...
        
                        
                



        
            
                
                    
                        Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
            
            
                
                    Star this course
                    
                        Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Unstar this course
                    
                        Remove star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024
                    
                
                
                    Restore to view
                    
                        Restore 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 to view
                    
                
                
                    Remove from view
                    
                        Remove 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024 from view
                    
                
            
                        
        

        ')]</value>
      <webElementGuid>15f4dcb6-abed-4e54-b0ea-468f2a93dc69</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
