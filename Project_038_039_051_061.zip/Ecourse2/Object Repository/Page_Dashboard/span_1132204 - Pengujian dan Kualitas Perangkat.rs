<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_1132204 - Pengujian dan Kualitas Perangkat</name>
   <tag></tag>
   <elementGuidId>62844c05-ea7e-4e22-b9e7-48b84451a50b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='course-info-container-2564-18']/div/div/a/span[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.multiline</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Course name 1132204 - Pengujian dan Kualitas Perangkat ...&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>98987479-90bf-41c7-ab80-f18cc2eb6be5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>multiline</value>
      <webElementGuid>1669d518-da5c-4249-b8f7-666fed6f4f26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            1132204 - Pengujian dan Kualitas Perangkat ...
        </value>
      <webElementGuid>dcd7b5c1-6ea8-4ce2-9e70-7fafe3ef1fe7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;course-info-container-2564-18&quot;)/div[@class=&quot;d-flex align-items-start&quot;]/div[@class=&quot;w-100 text-truncate&quot;]/a[@class=&quot;aalink coursename mr-2&quot;]/span[@class=&quot;multiline&quot;]</value>
      <webElementGuid>d758ff2e-8643-4d16-9ee5-2162678c04c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='course-info-container-2564-18']/div/div/a/span[3]</value>
      <webElementGuid>2c4974cc-7521-44aa-bffe-774cbefa0d6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Course name'])[2]/following::span[1]</value>
      <webElementGuid>c0814ace-05d6-45b7-8d81-861e48f006ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Course is starred'])[1]/following::span[2]</value>
      <webElementGuid>3ddd4bf5-0932-4e6a-abce-7604a163fb6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Actions for current course 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024'])[1]/preceding::span[1]</value>
      <webElementGuid>b14ce32b-6285-4337-8be7-0f76a28e271d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Star for 1132204 - Pengujian dan Kualitas Perangkat Lunak (D3-TI) 2023/2024'])[1]/preceding::span[2]</value>
      <webElementGuid>1fce9aa8-5b26-40d5-8f67-3edcdd877f69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='1132204 - Pengujian dan Kualitas Perangkat ...']/parent::*</value>
      <webElementGuid>3d31e16c-2d26-4b63-9247-dace00fc36cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]</value>
      <webElementGuid>1c0c3303-fe35-46cf-8515-1f9d996e031f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            1132204 - Pengujian dan Kualitas Perangkat ...
        ' or . = '
            1132204 - Pengujian dan Kualitas Perangkat ...
        ')]</value>
      <webElementGuid>3029a04a-5b00-47da-9da5-926c3f6f1d5f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
